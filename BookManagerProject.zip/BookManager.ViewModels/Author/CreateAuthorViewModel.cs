﻿namespace BookManager.ViewModels.Author;

public class CreateAuthorViewModel
{
    public string Name { get; set; } = null!;
}