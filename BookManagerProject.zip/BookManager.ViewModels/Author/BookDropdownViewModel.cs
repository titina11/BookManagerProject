﻿namespace BookManager.ViewModels.Authors
{
    public class BookDropdownViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
    }
}