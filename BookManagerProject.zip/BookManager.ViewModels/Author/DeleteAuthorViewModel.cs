﻿namespace BookManager.ViewModels.Author;

public class DeleteAuthorViewModel
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}