﻿namespace BookManager.ViewModels.Author;

public class DeleteAuthorViewModel
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;
}