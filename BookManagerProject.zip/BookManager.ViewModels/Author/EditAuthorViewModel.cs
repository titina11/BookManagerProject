﻿namespace BookManager.ViewModels.Author;

public class EditAuthorViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}