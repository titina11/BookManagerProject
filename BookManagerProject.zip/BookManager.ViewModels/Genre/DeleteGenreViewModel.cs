﻿namespace BookManager.ViewModels.Genre
{
    public class DeleteGenreViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}