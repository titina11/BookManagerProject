﻿namespace BookManager.ViewModels.Book
{
    public class GenreDropdownViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}