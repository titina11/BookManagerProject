﻿namespace BookManager.ViewModels.Book
{
    public class EditBookViewModel : CreateBookViewModel
    {
        public int Id { get; set; }

    }
}