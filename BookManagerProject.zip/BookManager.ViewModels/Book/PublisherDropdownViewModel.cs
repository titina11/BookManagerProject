﻿namespace BookManager.ViewModels.Book
{
    public class PublisherDropdownViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}