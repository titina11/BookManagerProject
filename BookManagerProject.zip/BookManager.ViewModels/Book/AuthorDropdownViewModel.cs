﻿namespace BookManager.ViewModels.Book
{
    public class AuthorDropdownViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}