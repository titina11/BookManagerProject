﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using BookManager.Data.Models;
using System;

public class BookConfiguration : IEntityTypeConfiguration<Book>
{
    public void Configure(EntityTypeBuilder<Book> builder)
    {
        builder.Property(b => b.Title)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(b => b.Description)
            .HasMaxLength(2000);

        builder.HasOne(b => b.Author)
            .WithMany(a => a.Books)
            .HasForeignKey(b => b.AuthorId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(b => b.Genre)
            .WithMany(g => g.Books)
            .HasForeignKey(b => b.GenreId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(b => b.Publisher)
            .WithMany(p => p.Books)
            .HasForeignKey(b => b.PublisherId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Property(b => b.ImageUrl)
            .HasMaxLength(500);

        builder.HasData(
            new Book
            {
                Id = Guid.Parse("7a1a29d6-70c4-4c02-9469-3b92d3d9b7ee"),
                Title = "Змията и крилете на нощта",
                AuthorId = Guid.Parse("9e340fd5-7f9e-43dc-96f0-07a3b9a1b12a"),     
                GenreId = Guid.Parse("e6a6a80b-9eb6-4ce3-92b5-00b5cf9a53db"),       
                Description = "„Змията и крилете на нощта“, първата книга от поредицата „Короните на Наяксия“ – любима на десетки хиляди читатели по света.",
                PublisherId = Guid.Parse("1f76d1f6-5c97-42b1-a5c7-e685b1541c1b"),   
                ImageUrl = "https://knigoman.bg/books/2303525764_1552613569786.png"
            },
            new Book
            {
                Id = Guid.Parse("89c68c41-e015-4bc2-8c03-4fbd7a0f2678"),
                Title = "Стъкленият трон",
                AuthorId = Guid.Parse("264a2a30-ec23-4aef-b1cb-8c7a4c9f7fa4"),     
                GenreId = Guid.Parse("e6a6a80b-9eb6-4ce3-92b5-00b5cf9a53db"),
                Description = "Селена Сардотиен е измъкната от затвора на Ендовер и единственият начин да спечели свободата си е да се пребори с най-жестоките мъже за титлата кралски убиец.",
                PublisherId = Guid.Parse("2a9cd570-96b6-4f52-b56d-137e2c5d5eaf"),
                ImageUrl = "https://cdn.ozone.bg/media/catalog/product/s/t//stakleniyat_tron_stakleniyat_tron_1_novo_izdanie_1713431567_0.jpg"
            },
            new Book
            {
                Id = Guid.Parse("e2e3609c-2641-4e4b-b67d-8852822451b4"),
                Title = "Игра на тронове (Песен за огън и лед 1)",
                AuthorId = Guid.Parse("fdddc2cb-718a-4cf3-9a8c-490c61cd31ae"),     
                GenreId = Guid.Parse("e6a6a80b-9eb6-4ce3-92b5-00b5cf9a53db"),
                Description = "Шеметен бяг от скована в жесток студ страна към земи на вечно лято и охолно безгрижие – сказание за владетели и чародеи, наемни убийци и незаконнородени претенденти.",
                PublisherId = Guid.Parse("3ff6d54c-b01a-4cc5-b289-15d20b92df7d"),
                ImageUrl = "https://cdn.ozone.bg/media/catalog/product/i/g/igra-na-tronove-pesen-za-og-n-i-led-1.jpg"
            }
        );
    }
}
