﻿namespace BookManager.GCommon
{
    public class ValidationConstants
    {

    }
}
